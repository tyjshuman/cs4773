package assign3;

import java.util.ArrayList;

public class ChecksToClear {
	private ArrayList<Check> checks = new ArrayList<Check>();

	public void newCheck(Check check) {
		checks.add(check);
	}
}
