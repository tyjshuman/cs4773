package assign3;

public class Teller extends BankEmployee {

}
