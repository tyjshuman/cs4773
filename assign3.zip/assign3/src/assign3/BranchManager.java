package assign3;

public class BranchManager extends BankEmployee {

}
