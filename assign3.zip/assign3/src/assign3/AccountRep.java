package assign3;

public class AccountRep extends BankEmployee {

}
